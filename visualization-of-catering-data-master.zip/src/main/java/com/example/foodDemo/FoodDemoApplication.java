package com.example.foodDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(FoodDemoApplication.class, args);
    }

}
