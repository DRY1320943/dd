package com.example.foodDemo.entity;

public class food {
    private String foodType;
    private String foodAddr;
    private Integer commentCount;
    private String taste;
    private String environment;
    private double service;
    private double cost;
    private String city;

    @Override
    public String toString() {
        return "food{" +
                "foodType='" + foodType + '\'' +
                ", foodAddr='" + foodAddr + '\'' +
                ", commentCount=" + commentCount +
                ", taste='" + taste + '\'' +
                ", environment='" + environment + '\'' +
                ", service=" + service +
                ", cost=" + cost +
                ", city='" + city + '\'' +
                '}';
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public String getFoodAddr() {
        return foodAddr;
    }

    public void setFoodAddr(String foodAddr) {
        this.foodAddr = foodAddr;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public String getTaste() {
        return taste;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public double getService() {
        return service;
    }

    public void setService(double service) {
        this.service = service;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
