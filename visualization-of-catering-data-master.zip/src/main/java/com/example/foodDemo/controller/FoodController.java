package com.example.foodDemo.controller;

import com.alibaba.fastjson.JSON;
import com.example.foodDemo.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.List;
import java.util.Map;

@Controller
public class FoodController {
    private final FoodService foodService;
    @Autowired
    public FoodController(FoodService foodService) {
        this.foodService = foodService;
    }

    //花费前十的平均口味评分、平均服务评分、平均环境评分
    @RequestMapping("/getCostTop10")
    @ResponseBody
    public String getCostTop10(){
        List<Map<String,Double>> costTopList = foodService.findCostTop10();
        String str = JSON.toJSONString(costTopList);
        System.out.println(str);
        return str;
    }

    //地区和平均消费关系
    @RequestMapping("/getAddrCost")
    @ResponseBody
    public String getAddrCost(){
        List<Map<String, Double>> addrCostMap = foodService.findAddrCost();
        String str = JSON.toJSONString(addrCostMap);
        System.out.println(str);
        return str;
    }

    //地区和服务评分的关系
    @RequestMapping("/getAddrService")
    @ResponseBody
    public String getAddrService(){
        List<Map<String, Double>> addrServiceMap = foodService.findAddrService();
        String str = JSON.toJSONString(addrServiceMap);
        System.out.println(str);
        return str;
    }

    @RequestMapping("/getTypeComment")
    @ResponseBody
    public String getTypeComment(){
        List<Map<String, Integer>> typeComment = foodService.findTypeComment();
        String str = JSON.toJSONString(typeComment);
        System.out.println(str);
        return str;
    }

    @RequestMapping("/getAddrEnvironment")
    @ResponseBody
    public String getAddrEnvironment(){
        List<Map<String, Double>> addrEnvironment = foodService.findAddrEnvironment();
        String str = JSON.toJSONString(addrEnvironment);
        System.out.println(str);
        return str;
    }
}
