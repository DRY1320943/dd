package com.example.foodDemo.service.impl;

import com.example.foodDemo.mapper.FoodMapper;
import com.example.foodDemo.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class FoodServiceImpl implements FoodService {

    private final FoodMapper foodMapper;

    @Autowired
    public FoodServiceImpl(FoodMapper foodMapper) {
        this.foodMapper = foodMapper;
    }

    @Override
    public List<Map<String, Double>> findCostTop10() {
        return foodMapper.findCostTop10();
    }

    @Override
    public List<Map<String, Double>> findAddrCost() {
        return foodMapper.findAddrCost();
    }

    @Override
    public List<Map<String, Double>> findAddrService() {
        return foodMapper.findAddrService();
    }

    @Override
    public List<Map<String, Integer>> findTypeComment() {
        return foodMapper.findTypeComment();
    }

    @Override
    public List<Map<String, Double>> findAddrEnvironment() {
        return foodMapper.findAddrEnvironment();
    }
}
