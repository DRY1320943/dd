package com.example.foodDemo.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface FoodMapper {
    //花费前十的平均口味评分、平均服务评分、平均环境评分
    List<Map<String,Double>> findCostTop10();

    //地区和平均消费关系
    List<Map<String,Double>> findAddrCost();

    //地区和服务评分的关系
    List<Map<String,Double>> findAddrService();

    //食物种类和点评人数的关系
    List<Map<String,Integer>> findTypeComment();

    //地区和环境的关系
    List<Map<String,Double>> findAddrEnvironment();
}
